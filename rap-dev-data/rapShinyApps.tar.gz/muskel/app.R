# app author: are.edvardsen@helse-nord.no
dir <- system.file("shinyApps", "muskel", package = "muskel")
setwd(dir)
shiny::shinyAppDir(".")

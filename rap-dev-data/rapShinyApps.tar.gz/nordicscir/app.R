# app author: Lena.Ringstad.Olsen@unn.no
dir <- system.file("shinyApps", "nordicscir", package = "nordicscir")
setwd(dir)
shiny::shinyAppDir(".")

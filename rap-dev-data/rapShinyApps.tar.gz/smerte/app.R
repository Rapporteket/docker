# app author: are.edvardsen@helse-nord.no
dir <- system.file("shinyApps", "smerte", package = "smerte")
setwd(dir)
shiny::shinyAppDir(".")

# author: are.edvardsen@helse-nord.no
dir <- system.file("shinyApps", "autoReport", package = "raptools")
setwd(dir)
shiny::shinyAppDir(".")

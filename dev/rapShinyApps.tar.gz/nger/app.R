# app author: Lena.Ringstad.Olsen@unn.no
dir <- system.file("shinyApps", "nger", package = "nger")
setwd(dir)
shiny::shinyAppDir(".")

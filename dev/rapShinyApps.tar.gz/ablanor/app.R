# app author: are.edvardsen@helse-nord.no
dir <- system.file("shinyApps", "ablanor", package = "ablanor")
setwd(dir)
shiny::shinyAppDir(".")

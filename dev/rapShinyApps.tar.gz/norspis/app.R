# app author: are.edvardsen@helse-nord.no
norspis::runApp()

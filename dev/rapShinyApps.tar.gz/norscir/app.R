# app author: Lena.Ringstad.Olsen@unn.no
nordicscir::kjor_NSapper(register='norscir')
